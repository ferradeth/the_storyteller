@extends('templates.admin')
@section('title', 'Подписки')
@section('content')
    @include('inc.message')
    <h1>Подписки</h1>
    <div class="grid-row head">
        <p>Период</p>
        <p>Дата оформления</p>
        <p>Автор</p>
        <p>Подписчик</p>
        <div></div>
    </div>
    @forelse($subs as $sub)
        <div class="grid-row">
            <p class="title">{{ $sub->period }} месяцев</p>
            <p>{{ $sub->created_at }}</p>
            <a href="{{ route('user.profile', $sub->user_id) }}">{{ $sub->user->username }}</a>
            <a href="{{ route('user.profile', $sub->sub_id) }}">{{ $sub->sub->username }}</a>
            <div class="btns">
                <form action="{{ route('admin.subs.del', $sub->id) }}" method="post">
                    @csrf
                    @method('delete')
                    <button class="btn ban">Отменить</button>
                </form>
                <button class="btn conf" data-id="{{ $sub->id }}">Подтвердить</button>
            </div>

        </div>
    @empty
        <p class="empty">Пусто</p>
    @endforelse

    <div id="modalWrapper" class="modal-wrapper">
        <div class="modal-window checking">
            <span id="closeBtn" class="close">&times;</span>
            <form id="actForm" action="">
                <h3>Подтвердите действие</h3>
                <input type="hidden" id="gameId" name="id">
                <div class="btns">
                    <button class="view btn-adm">Подтвердить</button>
                    <button class="close btn-adm">Отменить</button>
                </div>

            </form>
        </div>
    </div>
@endsection
@push('script')
    <script>
        document.querySelectorAll('.conf').forEach(item => {
            item.addEventListener('click', e => {
                modalWrapper.style.display = 'flex'
                gameId.value = e.target.dataset.id
                actForm.action = "{{ route('admin.subs.confirm') }}"
            })
        })

        document.querySelectorAll('.close').forEach(item => {
            item.addEventListener('click', e => {
                e.preventDefault()
                modalWrapper.style.display = 'none'
            })
        })
    </script>
@endpush
