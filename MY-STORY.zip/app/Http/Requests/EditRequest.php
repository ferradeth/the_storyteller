<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class EditRequest extends FormRequest
{

    public function rules()
    {
        return [
            'username'=>['required', 'regex:/^[а-яёa-z0-9\s-]+$/iu'],
            'password'=>['required', 'regex:/^(?=.*[0-9])(?=.*[!#&?])(?=.*[A-Z])[0-9a-zA-Z!#&?]{8,}/'],
        ];
    }

    public function messages(){
        return [
            'required'=>'Поле ":attribute" необходимо заполнить',
            'unique'=>'Поле ":attribute" должно быть уникальным',
            'regex'=>'Поле ":attribute" не соответствует шаблону',
        ];
    }

    public function attributes(){
        return [
            'username'=>'Имя',
            'password'=>'Пароль',
        ];
    }
}
