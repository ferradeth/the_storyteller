<?php

namespace App\Http\Controllers;

use App\Models\Sub;
use App\Models\User;
use Illuminate\Http\Request;

class SubController extends Controller
{
    public function sub(User $user, Request $request)
    {
        $res = false;

        if ($user->id != auth()->id()){
            $res = Sub::create(['user_id'=>$user->id, 'sub_id'=>auth()->id(), 'period'=>$request->period, 'payed'=>false]);
            mail('gainfoolish@gmail.com', 'Подписка на платформе The storyteller', "Вами была оформлена подписка на {$user->username}. Для активации подписки перейдите по ссылке ниже: \n КАКАЯ-ТО ССЫЛКА", 'From: gankachan130903@gmail.com');
        }

        return $res ? to_route('user.profile', $user->id)->with(['success'=>'Подписка успешно оформлена. На вашу почту пришло письмо с дальнейшими инструкциями.']) : to_route('user.profile', $user->id)->withErrors(['error'=>'Возникла ошибка при оформлении. Попробуйте позже.']);
    }

    public function unsub(User $user)
    {
        $res = Sub::where(['user_id'=>$user->id, 'sub_id'=>auth()->id()])->delete();
        return $res ? to_route('user.profile', $user->id)->with(['success'=>'Подписка отменена.']) : to_route('user.profile', $user->id)->withErrors(['error'=>'Невозможно отменить подписку']);
    }
}
