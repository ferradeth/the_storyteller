<?php $__env->startSection('title', 'Редактирование'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="media-reg">
        <a href="<?php echo e(route('user.profile')); ?>">Назад в профиль</a>
        <h1>Редактировать информацию профиля</h1>
        <form action="<?php echo e(route('user.update', auth()->id())); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="form-group">
                <label for="username"> Никнейм <span class="required">*</span></label>
                <input type="text" name="username" id="username" value="<?php echo e(old('username')??$user->username); ?>" required>
            </div>
            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group">
                <label for="email"> Электронная почта <span class="required">*</span></label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email')??$user->email); ?>" required>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group">
                <label for="desc"> Обо мне</label>
                <textarea name="description" id="description" rows="5" cols="15"><?php echo e(old('description')??$user->description); ?></textarea>
            </div>
            <div class="form-group">
                <label for="date"> Дата рождения <span class="required">*</span></label>
                <input type="date" name="birth_date" id="date" value="<?php echo e(old('birth_date')??$user->birth_date); ?>" required>
            </div>
            <div class="form-group">
                <label for="date"> Номер карты </label>
                <input type="text" name="card_number" id="card_number" value="<?php echo e(old('card_number')??$user->card_number); ?>">
            </div>

            <div class="form-group">
                <label for="new_pass">Новый пароль</label>
                <input type="password" name="password" id="password">
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="form-group">
                <label for="old_pass">Старый пароль</label>
                <input type="password" name="old_pass" id="old_pass">
            </div>

            <div class="form-group" id="cover-load">
                <label>Аватар</label>
                <label for="avatar" id="cover-label">
                    <div class="label-desc">Нажмите, чтобы загрузить изображение</div>
                    <input type="file" name="avatar" id="avatar" hidden="true">
                </label>
                <div id="file-cont">
                    <img src="<?php echo e($user->avatar); ?>" style="width: 200px; height: 200px; object-fit: cover" alt="avatar" id="avatarImg">
                </div>
            </div>

            <div class="form-group">
                <label for=""></label>
                <button name="submit" class="btn confirm" id="submit">Обновить</button>
            </div>
        </form>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="https://unpkg.com/imask"></script>
    <script>
        const loadFileAdd = document.querySelector('#avatar')
        const contCover = document.querySelector('#file-cont')

        loadFileAdd.addEventListener('change', e=>{
            avatarImg.src=URL.createObjectURL(e.target.files[0])
        })

        const cardInput = document.querySelector('#card_number')

        const maskOptions3 = {
            mask: '0000 0000 0000 0000',
            lazy: false
        }
        const mask3 = new IMask(cardInput, maskOptions3);
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/users/edit.blade.php ENDPATH**/ ?>