<?php $__env->startSection('title', 'Подписки'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Подписки</h1>
    <div class="grid-row head">
        <p>Период</p>
        <p>Дата оформления</p>
        <p>Автор</p>
        <p>Подписчик</p>
        <div></div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="grid-row">
            <p class="title"><?php echo e($sub->period); ?> месяцев</p>
            <p><?php echo e($sub->created_at); ?></p>
            <a href="<?php echo e(route('user.profile', $sub->user_id)); ?>"><?php echo e($sub->user->username); ?></a>
            <a href="<?php echo e(route('user.profile', $sub->sub_id)); ?>"><?php echo e($sub->sub->username); ?></a>
            <div class="btns">
                <form action="<?php echo e(route('admin.subs.del', $sub->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn ban">Отменить</button>
                </form>
                <button class="btn conf" data-id="<?php echo e($sub->id); ?>">Подтвердить</button>
            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="empty">Пусто</p>
    <?php endif; ?>

    <div id="modalWrapper" class="modal-wrapper">
        <div class="modal-window checking">
            <span id="closeBtn" class="close">&times;</span>
            <form id="actForm" action="">
                <h3>Подтвердите действие</h3>
                <input type="hidden" id="gameId" name="id">
                <div class="btns">
                    <button class="view btn-adm">Подтвердить</button>
                    <button class="close btn-adm">Отменить</button>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        document.querySelectorAll('.conf').forEach(item => {
            item.addEventListener('click', e => {
                modalWrapper.style.display = 'flex'
                gameId.value = e.target.dataset.id
                actForm.action = "<?php echo e(route('admin.subs.confirm')); ?>"
            })
        })

        document.querySelectorAll('.close').forEach(item => {
            item.addEventListener('click', e => {
                e.preventDefault()
                modalWrapper.style.display = 'none'
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/subs.blade.php ENDPATH**/ ?>