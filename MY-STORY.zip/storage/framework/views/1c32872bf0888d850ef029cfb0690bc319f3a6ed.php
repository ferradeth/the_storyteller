<?php $__env->startSection('title', 'Администрирование игр'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($user): ?>
        <a href="<?php echo e(route('admin.games.index')); ?>">Вернуться к общему списку</a>
    <?php endif; ?>
    <h1>Список игр <?php echo e($user??''); ?></h1>
    <div class="cont">
        <div class="grid-row head">
            <p>Название игры</p>
            <p>Количество лайков</p>
            <p>Автор</p>
            <p>Количество дизлайков</p>
            <div></div>
        </div>
        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="grid-row">
                <a href="<?php echo e(route('games.show', $game->id)); ?>" class="title"><?php echo e($game->name); ?></a>
                <p><?php echo e($game->count_likes); ?></p>
                <a href="<?php echo e(route('admin.games.index', $game->user_id)); ?>"><?php echo e($game->user->username); ?></a>
                <p class="count_bans"><?php echo e($game->count_dislikes); ?></p>
                <div class="btns">
                    <button
                        class="btn ban"
                        data-baned="<?php echo e($game->baned); ?>" data-id="<?php echo e($game->id); ?>"><?php echo e($game->baned ?"Разблокировать":"Заблокировать"); ?></button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div id="modalWrapper" class="modal-wrapper">
        <div class="modal-window checking">
            <span id="closeBtn" class="close">&times;</span>
            <form id="actForm" action="">
                <h3>Подтвердите действие</h3>
                <input type="hidden" id="gameId" name="game_id">
                <div class="btns">
                    <button class="view btn-adm">Подтвердить</button>
                    <button class="close btn-adm">Отменить</button>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        document.querySelectorAll('.ban').forEach(item => {
            item.addEventListener('click', e => {
                modalWrapper.style.display = 'flex'
                gameId.value = e.target.dataset.id
                actForm.action = e.target.dataset.baned === 1 ?"<?php echo e(route('admin.games.unban')); ?>":"<?php echo e(route('admin.games.ban')); ?>"
            })
        })

        document.querySelectorAll('.close').forEach(item => {
            item.addEventListener('click', e => {
                modalWrapper.style.display = 'none'
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/games.blade.php ENDPATH**/ ?>