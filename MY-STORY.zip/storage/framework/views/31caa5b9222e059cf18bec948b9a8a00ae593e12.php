<?php $__env->startSection('title', 'Администраторы'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Администраторы</h1>
    <div class="cont">
        <div class="grid-row head">
            <p>Логин</p>
            <p></p>
            <p></p>
            <p></p>
            <p><button id="addAdmin" class="btn"> Добавить администратора </button></p>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="grid-row">
                <p class="title"><?php echo e($admin->login); ?></p>
                <p></p>
                <p></p>
                <button class="btn update" data-tag="<?php echo e($admin->id); ?>">Обновить</button>
                <form method="post" action="<?php echo e(route('admin.admins.delete', $admin->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn ban">Удалить</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty">Пусто</p>
        <?php endif; ?>
    </div>

    <div id="modalWrapper" class="modal-wrapper">
        <div class="modal-window">
            <span id="closeBtn">&times;</span>
            <form action="" id="form" method="post">
                <?php echo csrf_field(); ?>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        const createBtn = document.getElementById('addAdmin')
        const updateBtns = document.querySelectorAll('.update')

        createBtn.addEventListener('click', (e)=>{
            // modalWrapper.classList.toggle('hide')
            modalWrapper.style.display = "flex";
            form.action = "<?php echo e(route('admin.admins.create')); ?>"
            form.textContent = ''
            form.insertAdjacentHTML('afterbegin', `
                <input type="text" name="login" placeholder="Логин" style="margin-bottom: 5px">
                <button class="btn" style="width: 100%">Подтвердить</button>`)
            form.insertAdjacentHTML('afterbegin', ` <input type="password" name="password" placeholder="Пароль"  style="margin-bottom: 5px">`)
            form.insertAdjacentHTML('afterbegin', `<h3>Добавить админа</h3>`)
        })

        updateBtns.forEach(btn=>{
            btn.addEventListener('click', e=>{
                console.log(e.currentTarget.dataset.tag)
                // modalWrapper.classList.toggle('hide')
                modalWrapper.style.display = "flex";
                form.action = "<?php echo e(route('admin.admins.update')); ?>"
                form.textContent = ''
                form.insertAdjacentHTML('afterbegin', `
                <input type="text" name="login" placeholder="Логин" style="margin-bottom: 5px">
                <button class="btn" style="width: 100%">Подтвердить</button>`)
                form.insertAdjacentHTML('afterbegin', `<h3>Изменить логин</h3>`)
                form.insertAdjacentHTML('beforeend', `
                <input type="hidden" name="id" value="${e.currentTarget.dataset.tag}">`)
            })
        })
        closeBtn.addEventListener('click', ()=>{
            modalWrapper.style.display = "none";
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/admins.blade.php ENDPATH**/ ?>