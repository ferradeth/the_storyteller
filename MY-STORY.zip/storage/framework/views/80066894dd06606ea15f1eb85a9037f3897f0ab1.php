<?php $__env->startSection('title', 'My story'); ?>
<?php $__env->startSection('content'); ?>
<main class="main-page">
    <section>
        <div class="popular">
            <div class="header">Популярное</div>
            <div class="popular-games">
                <?php $__empty_1 = true; $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('games.show', $game->id)); ?>">
                        <div class="pop-game" style="background: linear-gradient(to top, rgb(0,0,0) 0%, rgba(255,255,255,0) 100%), url('<?php echo e($game->cover); ?>'); background-size: cover; background-position: center">
                            
                            <p class="pop-game-title"><?php echo e($game->name); ?></p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty">Пока тут пусто :(</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="last-update">
            <div class="update-head">
                <p>Последние обновления</p>
                <div class="filt-updates">
                    <button class="all active" id="all">Все</button>
                    <?php if(auth()->guard()->check()): ?>
                    <button class="subs" id="subs">Подписки</button>
                    <?php endif; ?>
                </div>
            </div>
            <div class="container">

                <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo $__env->make('inc.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty">Пока тут пусто :(</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <section>
        <div class="top-authors">
            <div class="header">Топ авторов</div>
            <ol class="authors">

                <?php
                  $number =  1;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $top_authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="author-top">
                        <span class="top-number"><?php echo e($key+1); ?></span>
                        <div class="user-info">
                            <img class="user-top-img" src="<?php echo e($author->avatar); ?>" alt="profile pic">
                            <a href="<?php echo e(route('user.profile', $author->id)); ?>"><?php echo e($author->username); ?></a>
                        </div>
                        <span class="followers"><?php echo e($author->numberFollowers()); ?></span>
                    </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty">Станьте первым!</p>
                <?php endif; ?>
            </ol>
        </div>
        <div class="tags-cont">
            <div class="header">Метки</div>
            <div class="tags-name">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('games.catalog', $tag->id)); ?>" class="tag"><?php echo e($tag->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/fetch.js')); ?>"></script>
    <script>
        const allBtn = document.querySelector('#all')
        const subBtn = document.querySelector('#subs')

        function likes(){
            const likeBtns = document.querySelectorAll('.likes')

            likeBtns.forEach(elem =>{
                elem.addEventListener('click', async (e)=>{
                    console.log(e.currentTarget.dataset.item)
                    if (elem.dataset.user){
                        let res = await postDataJSON('<?php echo e(route('games.like')); ?>', e.currentTarget.dataset.item, '<?php echo e(csrf_token()); ?>');
                        if(res){
                            elem.style.background = '#7645C7';
                            let last = document.querySelector(`div[data-item="${elem.dataset.item}"] span`).textContent;
                            console.log(last)
                            document.querySelector(`div[data-item="${elem.dataset.item}"] span`).textContent = (parseInt(last) + 1).toString()
                            elem.children[0].src = "<?php echo e(asset('/icons/like-active.svg')); ?>";
                        }
                        console.log(res)
                    }
                    else{
                        location = "<?php echo e(route('login')); ?>"
                    }
                })
            })
        }
        likes()


        allBtn.addEventListener('click', ()=>{
            subs.classList.toggle('active')
            all.classList.toggle('active')
            document.querySelector('.container').textContent = ''
            document.querySelector('.container').insertAdjacentHTML('beforeend', `
            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('inc.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            `)
            likes()
        })

        subBtn.addEventListener('click',()=>{
            subs.classList.toggle('active')
            all.classList.toggle('active')
            document.querySelector('.container').textContent = ''
            document.querySelector('.container').insertAdjacentHTML('beforeend',
                `<?php $__empty_1 = true; $__currentLoopData = $games_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo $__env->make('inc.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty">Тут пока пусто</p>
                <?php endif; ?>`

            )
            likes()
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/index.blade.php ENDPATH**/ ?>