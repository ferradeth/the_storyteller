<div class="card <?php echo e($game->access_id ==3 && auth()->id() != $game->user_id ? 'hide': ''); ?>" >
    <img src="<?php echo e($game->cover); ?>" alt="" class="card-img">
    <div class="card-body">
        <div class="card-body-top">
            <a href="<?php echo e(route('games.show', $game->id)); ?>" class="game-title"><?php echo e($game->name); ?></a>
            <p class="game-tags"> Тэги:

                <?php $__empty_1 = true; $__currentLoopData = $game->gameTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('games.catalog', $tag->tag_id)); ?>" class="tags"><?php echo e($tag->tag->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span>Метки отсутствуют</span>
                <?php endif; ?>
            </p>
            <a href="<?php echo e(route('user.profile', $game->user_id)); ?>" class="game-author">Автор: <?php echo e($game->user->username); ?></a>
            <p class="game-description" style="margin-top: 5px">Описание: <?php echo e($game->description); ?></p>
        </div>
        <p class="date-last-update">Последнее обновление: <?php echo e($game->dateClassic($game->updated_at)); ?></p>
    </div>
    <div class="likes" data-item="<?php echo e($game->id); ?>" data-user="<?php echo e(auth()->check()); ?>">
        <?php if(auth()->user() != null): ?>
            <img src="<?php echo e(count(auth()->user()->existLike($game->id))>0 ? asset('/icons/like-active.svg'): asset('/icons/like-black.svg')); ?>" alt="likes">
        <?php else: ?>
            <img src="<?php echo e(asset('/icons/like-black.svg')); ?>" alt="likes">
        <?php endif; ?>
        <span><?php echo e($game->count_likes); ?></span>
    </div>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        const descs = document.querySelectorAll('.game-description')

        descs.forEach(elem=>{
            elem.textContent = limitStr(elem.textContent, 100)
        })
        function limitStr(str, n, symb) {
            if (!n && !symb ) return str;
            if (str.length<n) return str;
            symb = symb || '...';
            return str.substr(0, n - symb.length) + symb;
        }
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/inc/card.blade.php ENDPATH**/ ?>