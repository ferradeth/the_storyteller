<?php $__env->startSection('title', 'Блокировка пользователей'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Пользователи</h1>
    <div class="cont">
        <div class="grid-row head">
            <p>Никнейм</p>
            <p>Почта</p>
            <p>Количество подписок</p>
            <p>Количество подписчиков</p>
            <div>
            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="grid-row">
                <a href="<?php echo e(route('user.profile', $user->id)); ?>" class="title"><?php echo e($user->username); ?></a>
                <p><?php echo e($user->email); ?></p>
                <a href="<?php echo e(route('admin.users.subscribes', $user->id)); ?>"><?php echo e($user->numberSubs()); ?></a>
                <a href="<?php echo e(route('admin.users.followers', $user->id)); ?>"><?php echo e($user->numberFollowers()); ?></a>
                <div class="btns">
                    <a href="<?php echo e($user->ban ?route('admin.users.unban', $user->id):route('admin.users.ban', $user->id)); ?>" class="btn ban"><?php echo e($user->ban ?"Разблокировать":"Заблокировать"); ?></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty">Пусто</p>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/users.blade.php ENDPATH**/ ?>