<?php $__env->startSection('title', $game->name); ?>
<?php $__env->startSection('content'); ?>

    <main>
        <a href="<?php echo e(route('games.index')); ?>">Назад</a>
        <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(!$game->baned): ?>
            <p id="statusMessage" class="alert alert-success" hidden></p>
            <div class="main-game-info">
                <img class="main-game-img" src="<?php echo e($game->cover); ?>">
                <div class="main-game-chars">
                    <div class="title-row">
                        <div class="title-left">
                            <p class="main-game-title"><?php echo e($game->name); ?></p>
                            <?php if(auth()->guard()->check()): ?>
                            <form method="post">
                                <?php echo csrf_field(); ?>
                                <select id="statusSelect">
                                    <option value="0" data-game="<?php echo e($game->id); ?>" hidden> Присвоить статус...</option>
                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($game->gameStatuses->where('user_id', auth()->id())->first() != null): ?>
                                            <option value="<?php echo e($status->id); ?>" data-game="<?php echo e($game->id); ?>" class="status-trigger" <?php echo e(auth()->check() && $game->gameStatuses->where('user_id', auth()->id())->first()->status_id == $status->id? 'selected': ''); ?>><?php echo e($status->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($status->id); ?>" data-game="<?php echo e($game->id); ?>" class="status-trigger"><?php echo e($status->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>
                            <?php endif; ?>
                        </div>
                        <div class="addition-inf">
                            <p><?php echo e($game->dateClassic($game->updated_at)); ?></p>
    
                            <div class="like">
                                <?php if(auth()->user() != null): ?>
                                    <img src="<?php echo e(count(auth()->user()->existLike($game->id))>0 ? asset('/icons/like-active.svg'): asset('/icons/like-black.svg')); ?>" alt="likes" id="like" data-game="<?php echo e($game->id); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('/icons/like-black.svg')); ?>" alt="likes" id="like" data-game="<?php echo e($game->id); ?>">
                                <?php endif; ?>
                                <p><?php echo e($game->count_likes); ?></p>
                            </div>


                            <div class="like">
                                <?php if(auth()->user() != null): ?>
                                    <img src="<?php echo e(count(auth()->user()->existDislike($game->id))>0 ? asset('/icons/dislike-active.svg'): asset('/icons/dislike.svg')); ?>" alt="dislikes" id="dislike" data-game="<?php echo e($game->id); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('/icons/dislike.svg')); ?>" alt="dislikes" id="dislike" data-game="<?php echo e($game->id); ?>">
                                <?php endif; ?>
                                <p><?php echo e($game->count_dislikes); ?></p>
                            </div>
                        </div>
                    </div>

                    <a href="<?php echo e(route('user.profile', $game->user_id)); ?>" class="game-author">Автор: <?php echo e($game->user->username); ?></a>
                    <p class="main-game-tags"> Тэги:
                        
                        <?php $__empty_1 = true; $__currentLoopData = $game->gameTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="#" class="main-tags"><?php echo e($tag->tag->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span>Метки отсутствуют</span>
                        <?php endif; ?>
                    </p>

                    <p class="game-language">Язык: <?php echo e($game->language); ?></p>
                    <p class="game-favs">Добавило в избранные: <?php echo e($game->numberOfFavs()); ?></p>
                    <p id="game-downloads">Скачиваний: <?php echo e($game->count_downloads); ?></p>
                    <div class="game-desc">Описание: <?php echo e($game->description); ?></div>
                    <?php if($game->ban <= 5 && $game->access_id == 1): ?>
                        <a class="game-link" href="<?php echo e($game->file_link); ?>" id="download" data-game="<?php echo e($game->id); ?>">Скачать новеллу</a>
                    <?php elseif($game->access_id == 2): ?>
                        <?php if(auth()->check()?count(auth()->user()->checkSub($game->user_id))>0:false): ?>
                            <a class="game-link" href="<?php echo e($game->file_link); ?>" id="download" data-game="<?php echo e($game->id); ?>">Скачать новеллу</a>
                        <?php else: ?>
                            <button class="game-link" id="makeSub">Оформите подписку для скачивания</button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="game-screens">
                <h3 class="show-h">Скриншоты</h3>
                <div class="screens-cont">
                    <?php if( count($game->images)>0): ?>
    
                        <div class="slider">
                            <?php $__currentLoopData = $game->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                    <img src="<?php echo e($image->image); ?>" alt="screen" class="slider-img">


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>

                <?php else: ?>
                    <p>Скриншоты пока отсутсвуют.</p>
                <?php endif; ?>
            </div>
            <form class="comment-input" method="<?php echo e(auth()->check()? 'post':'get'); ?>" action="<?php echo e(auth()->check()?route('comments.store', $game->id):route('login')); ?>">
                <?php echo csrf_field(); ?>
                <h3 class="show-h">Комментарии</h3>
                <textarea type="text" placeholder="Написать комментарий..." name="message" style="width: 100%; height: 80px; text-align: start; resize: none; margin-bottom: 10px"></textarea>
                <button class="btn sub">Отправить</button>
            </form>
            <div class="comment-cont">
                <?php $__currentLoopData = $game->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="comment-item">
                        <img src="<?php echo e($comment->user->avatar); ?>" alt="avatar" class="comment-img">
                        <div class="comment-info">
                            <div class="title-row">
                                <p class="comment-author"><?php echo e($comment->user->username); ?></p>
                                <p><?php echo e($comment->dateClassic()); ?></p>
                            </div>
                            <p class="comment-content"><?php echo e($comment->message); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p class="empty">Игра заблокирована :(</p>
        <?php endif; ?>
    </main>

    <div class="modal-wrapper hide" id="modalWrapper">
        <div class="modal-window">
            <span id="closeBtn">&times;</span>
            <form method="post" action="<?php echo e(route('sub.make', $game->user_id)); ?>">
                <?php echo csrf_field(); ?>
                <h3>Выберите длительности подписки:</h3>
                <div class="sub-label">
                    <label class="sub-ver">
                        <input type="radio" name="period" value="1" hidden>
                        <p>Месяц</p>
                        <span>300 рублей</span>
                    </label>
                    <label class="sub-ver">
                        <input type="radio" name="period" value="12" hidden>
                        <p>Год</p>
                        <span>3600 рублей</span>
                    </label>
                </div>
                <button class="btn sub">Оформить подписку</button>
                <p class="modal-info">Подписка в любой момент может быть отменена. Оплата возврату не подлежит</p>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/fetch.js')); ?>"></script>
    <script>
        // const options = document.querySelectorAll('.status-trigger')
        // console.log(options)
        // options.forEach(elem=>{
            statusSelect.addEventListener('change', async ()=>{
                console.log(statusSelect.children)
                const options = statusSelect.childNodes
                let statusOpt;
                options.forEach(child=>{
                    if(child.selected) {
                        console.log(child.value)
                        statusOpt = child
                    }
                })
                let res = await postDataJSON("<?php echo e(route('games.status')); ?>", { 'id' : statusOpt.dataset.game, 'status_id': statusOpt.value}, "<?php echo e(csrf_token()); ?>")
                statusMessage.hidden = false
                if (res){
                    statusMessage.textContent = 'Статус успешно установлен!'
                }
                else{
                    statusMessage.textContent = 'Не удалось поменять статус'
                }

            // })
        })
    </script>
    <script>
        const subVer = document.querySelectorAll('.sub-ver')
        makeSub.addEventListener('click', e =>{
            console.log(makeSub)
            // console.log(modalWrapper.classList.toggle('hide'))
            modalWrapper.classList.toggle('hide')
        })

        closeBtn.addEventListener('click', ()=>{
            modalWrapper.classList.toggle('hide')
        })

        const clearActive = () => {
            subVer.forEach(item => {
                item.classList.remove('active')
            });
        }

        subVer.forEach(elem=>{
            console.log(elem)
            elem.addEventListener('change', e=>{
                // console.log(e.currentTarget.classList.toggle('active'))
                // e.currentTarget.classList.toggle('active')
                // console.log(elem.classList.contains('active'))
                if(elem.children[0].checked){
                    console.log(elem.children[0].checked)
                    clearActive()
                    elem.classList.contains('active')?elem.classList.remove('active'):elem.classList.add('active')
                }

            })
        })

    </script>

    <script>
        dislike.addEventListener('click', async e=>{
            let res = await postDataJSON("<?php echo e(route('games.dislike')); ?>", e.target.dataset.game, "<?php echo e(csrf_token()); ?>")
            // if (res){
            //     statusMessage.textContent = 'Жалоба отправлена!'
            // }
            if (res){
                dislike.src = "<?php echo e(asset('icons/dislike-active.svg')); ?>"
                let last = e.target.parentNode.children[1].textContent
                console.log(e.target.parentNode.children[1])
                e.target.parentNode.children[1].textContent = (parseInt(last) + 1).toString()
            }

        })
        like.addEventListener('click', async e=>{
            let res = await postDataJSON("<?php echo e(route('games.like')); ?>", e.target.dataset.game, "<?php echo e(csrf_token()); ?>")
            console.log(res)
            if (res){
                e.target.src = "<?php echo e(asset('icons/like-active.svg')); ?>"
                let last = e.target.parentNode.children[1].textContent
                console.log(e.target.parentNode.children[1])
                e.target.parentNode.children[1].textContent = (parseInt(last) + 1).toString()
            }

        })
    </script>

    <script>
        download.addEventListener('click', async e=>{
            // e.preventDefault()
            let res = await postDataJSON("<?php echo e(route('games.download')); ?>", download.dataset.game, "<?php echo e(csrf_token()); ?>")
            if (res){
                document.getElementById("game-downloads").textContent = "Скачиваний: " + res.toString()
            }
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/games/show.blade.php ENDPATH**/ ?>