<nav>
    <a href="<?php echo e(route('admin.logout')); ?>" class="btn-adm">Выход</a>
    <a href="<?php echo e(route('admin.index')); ?>">Главная</a>
    <a href="<?php echo e(route('admin.games.check')); ?>">Ожидают подтверждения</a>
    <a href="<?php echo e(route('admin.games.canceled')); ?>">Отклонённые игры</a>
    <a href="<?php echo e(route('admin.games.index')); ?>">Список игр</a>
    <a href="<?php echo e(route('admin.admins.index')); ?>">Администраторы</a>
    <a href="<?php echo e(route('admin.users.index')); ?>">Блокировка пользователей</a>
    <a href="<?php echo e(route('admin.tags.index')); ?>">Тэги</a>
    <a href="<?php echo e(route('admin.comments.index')); ?>">Комментарии</a>
    <a href="<?php echo e(route('admin.subs.index')); ?>">Подписки</a>
</nav>
<?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/inc/adm-header.blade.php ENDPATH**/ ?>