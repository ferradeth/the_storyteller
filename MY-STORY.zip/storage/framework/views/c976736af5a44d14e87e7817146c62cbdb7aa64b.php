<?php $__env->startSection('title', 'Блокировка пользователей'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <a href="<?php echo e(route('admin.users.index')); ?>">Вернуться к списку пользователей</a>
    <?php if($followers??false): ?>
        <h1>Подписчики <?php echo e($user); ?></h1>
    <?php elseif($subscribes): ?>
        <h1>Подписки <?php echo e($user); ?></h1>
    <?php endif; ?>

    <div class="cont">
        <div class="grid-row head">
            <p>Никнейм</p>
            <p>Почта</p>
            <p>Количество подписок</p>
            <p>Количество подписчиков</p>
            <div>
            </div>
        </div>
        <?php if($followers??false): ?>
            <?php $__empty_1 = true; $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="grid-row">
                    <p class="title"><?php echo e($follow->sub->username); ?></p>
                    <p><?php echo e($follow->sub->email); ?></p>
                    <p><?php echo e($follow->sub->numberSubs()); ?></p>
                    <p><?php echo e($follow->sub->numberFollowers()); ?></p>
                    <div class="btns">
                        <a href="<?php echo e($follow->sub->ban ?route('admin.users.unban', $follow->sub->id):route('admin.users.ban', $follow->sub->id)); ?>" class="btn ban"><?php echo e($follow->sub->ban ?"Разблокировать":"Заблокировать"); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="empty">Пусто</p>
            <?php endif; ?>
        <?php elseif($subscribes): ?>
            <?php $__empty_1 = true; $__currentLoopData = $subscribes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="grid-row">
                    <p class="title"><?php echo e($follow->user->username); ?></p>
                    <p><?php echo e($follow->user->email); ?></p>
                    <p><?php echo e($follow->user->numberSubs()); ?></p>
                    <p><?php echo e($follow->user->numberFollowers()); ?></p>
                    <div class="btns">
                        <a href="<?php echo e($follow->user->ban ?route('admin.users.unban', $follow->user->id):route('admin.users.ban', $follow->user->id)); ?>" class="btn ban"><?php echo e($follow->user->ban ?"Разблокировать":"Заблокировать"); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="empty">Пусто</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/user_subs.blade.php ENDPATH**/ ?>