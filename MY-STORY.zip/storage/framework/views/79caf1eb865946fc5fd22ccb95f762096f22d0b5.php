<?php $__env->startSection('title', 'Тэги'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Список тэгов</h1>
    <button class="btn" id="create" style="margin-bottom: 15px">Добавить тэг</button>
    <div class="cont">
    <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="grid-row">
            <p class="title"><?php echo e($tag->name); ?></p>
            <div></div>
            <div></div>
            <button class="btn update" data-tag="<?php echo e($tag->id); ?>">Обновить</button>
            <form class="post" action="<?php echo e(route('admin.tags.delete', $tag->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn ban">Удалить</button>
            </form>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="empty">Пусто</p>
    <?php endif; ?>
    </div>

    <div id="modalWrapper" class="modal-wrapper">
        <div class="modal-window">
            <span id="closeBtn">&times;</span>
            <form action="" id="form" method="post">
                <?php echo csrf_field(); ?>
                <h3 id="modalTitle">Добавить тэг</h3>

                <input type="text" name="name">
                <button class="btn" style="width: 100%">Подтвердить</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        const createBtn = document.getElementById('create')
        const updateBtns = document.querySelectorAll('.update')

        createBtn.addEventListener('click', (e)=>{
            // modalWrapper.classList.toggle('hide')
            modalWrapper.style.display = "flex";
            form.action = "<?php echo e(route('admin.tags.create')); ?>"
            modalTitle.textContent = 'Добавить тэг'
        })

        updateBtns.forEach(btn=>{
            btn.addEventListener('click', e=>{
                console.log(e.currentTarget.dataset.tag)
                // modalWrapper.classList.toggle('hide')
                modalWrapper.style.display = "flex";
                form.action = "<?php echo e(route('admin.tags.update')); ?>"
                modalTitle.textContent = 'Изменить тэг'
                form.insertAdjacentHTML('beforeend', `
                <input type="hidden" name="id" value="${e.currentTarget.dataset.tag}">`)
            })
        })
        closeBtn.addEventListener('click', ()=>{
            modalWrapper.style.display = "none";
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/tags.blade.php ENDPATH**/ ?>