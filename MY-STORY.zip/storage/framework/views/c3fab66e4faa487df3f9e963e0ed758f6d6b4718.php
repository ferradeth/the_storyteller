<?php $__env->startSection('title', 'Админ-панель'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Игры с 5+ дизлайков</h1>
    <div class="cont">
        <div class="grid-row head">
            <p>Название игры</p>
            <p>Описание игры</p>
            <p>Автор</p>
            <p>Количество жалоб</p>
            <div>

            </div>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="grid-row">
                <a href="<?php echo e(route('games.show', $game->id)); ?>" class="title"><?php echo e($game->name); ?></a>
                <p class="description"><?php echo e($game->description); ?></p>
                <p class="game-author"><?php echo e($game->user->username); ?></p>
                <p class="count_bans"><?php echo e($game->ban); ?></p>
                <div class="btns">
                    <a href="<?php echo e($game->baned ?route('admin.games.unban', $game->id):route('admin.games.ban', $game->id)); ?>" class="btn ban"></a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty">Пусто</p>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/index.blade.php ENDPATH**/ ?>