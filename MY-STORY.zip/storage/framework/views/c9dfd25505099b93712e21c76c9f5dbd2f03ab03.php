<?php $__env->startSection('title', 'Комментарии'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1>Комментарии</h1>
    <div class="grid-row head">
        <p>Автор</p>
        <p>Комментарий</p>
        <p>Дата создания</p>
        <p></p>
        <div>



                <button class="btn ban" id="deleteBtn">Удалить выбранные</button>
            </form>
        </div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="grid-row" id="id<?php echo e($comment->id); ?>">
            <p class="title"><?php echo e($comment->user->username); ?></p>
            <p><?php echo e($comment->message); ?></p>
            <p><?php echo e($comment->created_at); ?></p>
            <p> <input type="checkbox" value="<?php echo e($comment->id); ?>" name="comments"></p>





        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="empty">Пусто</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/fetch.js')); ?>"></script>
    <script>
        deleteBtn.addEventListener('click', async ()=>{
            const checked = document.querySelectorAll("input[type='checkbox']:checked")
            // console.log(checked[0].value)
             let array = [...checked].map((elem)=>elem.value)

            let res = await postDataJSON("<?php echo e(route('admin.comments.delete')); ?>", array, "<?php echo e(csrf_token()); ?>")
            if (res) {
                alert('Комментарии успешно удалены')
                array.forEach(id=>{
                    document.getElementById(`id${id}`).remove()
                })
            }
            else alert('Не удалось удалить комментарии')
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/comments.blade.php ENDPATH**/ ?>