<nav>
    <div class="left col">
        <a href="<?php echo e(route('games.index')); ?>" id="logo"> The storyteller </a>

        <form class="search" action="<?php echo e(route('games.search')); ?>">
            <input type="text" name="search" placeholder="Поиск по сайту">
            <button id="search"> <img src="<?php echo e(asset('icons/search.svg')); ?>" alt="поиск"> </button>
        </form>
    </div>

    <div class="right col">
        <a href="<?php echo e(route('games.catalog')); ?>" class="pages">Каталог</a>
        <a href="<?php echo e(route('info')); ?>" class="pages">О нас</a>






        <?php if(auth()->guard()->guest()): ?>
            <a class="nav-link signup" href="<?php echo e(route('login')); ?>">Вход</a>
            <a class="nav-link register" href="<?php echo e(route('user.reg')); ?>">Регистрация</a>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <button id="notifications">
                <img src="<?php echo e(asset('icons/notify.svg')); ?>" alt="уведомления">
            </button>

            <button id="profile">
                <img src="<?php echo e(auth()->user()->avatar); ?>" alt="изображение профиля">
            </button>

            <div class="menu hide" id="profileMenu">
                <a class="menu-link" id="link1" href="<?php echo e(route('user.profile')); ?>">Мой профиль</a>
                <a class="menu-link" href="<?php echo e(route('user.edit')); ?>">Настройки профиля</a>
                <a class="menu-link" href="<?php echo e(route('logout')); ?>">Выход</a>
            </div>
            <div class="notify-menu hide" id="notifyMenu">
                <h3>Уведомления</h3>
                <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="notify">
                        <p class="date"><?php echo e($notify->created_at); ?></p>
                        <p><?php echo e($notify->message); ?></p>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty notify"> Пока нет уведомлений</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</nav>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/script.js')); ?>">
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/inc/header.blade.php ENDPATH**/ ?>