<form action="<?php echo e(route('games.filter')); ?>" method="get" class="filter">
    <?php if(isset($user)): ?>
        <input type="hidden" value="<?php echo e($user ? $user->id : ''); ?>" name="user">
        <input type="hidden" value="" id="tab-id" name="tab">
    <?php endif; ?>
    <div class="sort">
        <p class="filt-head">Сортировка</p>
        <label>
            <input type="radio" name="sort"
                   value="name" <?php echo e(old('filters')? isset(old('filters')['sort'])? old('filters')['sort']=='name'?'checked':'':'':''); ?>>
            По названию
        </label>
        <label>
            <input type="radio" name="sort"
                   value="updated_at" <?php echo e(old('filters')? isset(old('filters')['sort'])?  old('filters')['sort']=='updated_at'?'checked':'':'':''); ?>>
            По дате обновления
        </label>
        <label>
            <input type="radio" name="sort"
                   value="created_at" <?php echo e(old('filters')? isset(old('filters')['sort'])? old('filters')['sort']=='created_at'?'checked':'':'':''); ?>>
            По дате создания
        </label>
        <label>
            <input type="radio" name="sort"
                   value="count_likes" <?php echo e(old('filters')? isset(old('filters')['sort'])? old('filters')['sort']=='count_like'?'checked':'':'':''); ?>>
            По количеству лайков
        </label>
    </div>
    <hr>
    <div class="sort">
        <p class="filt-head">Порядок сортировки</p>
        <label>
            <input type="radio" name="orderSort"
                   value="desc" <?php echo e(old('filters')? isset(old('filters')['orderSort'])? old('filters')['orderSort']=='desc'?'checked':'':'':''); ?>>
            По убыванию
        </label>
        <label>
            <input type="radio" name="orderSort"
                   value="asc" <?php echo e(old('filters')? isset(old('filters')['orderSort'])? old('filters')['orderSort']=='asc'?'checked':'':'':''); ?>>
            По возрастанию
        </label>
    </div>
    <hr>
    <div class="tags_filt">
        <p class="filt-head">Тэги</p>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label>
                <input type="checkbox" value="<?php echo e($tag->id); ?>"
                       name="tags[]" <?php echo e(array_search($tag->id, old('filters')['tags']??[])?'checked':''); ?>>
                <?php echo e($tag->name); ?>

            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <button class="btn">Применить</button>
</form>
<?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/inc/filter.blade.php ENDPATH**/ ?>