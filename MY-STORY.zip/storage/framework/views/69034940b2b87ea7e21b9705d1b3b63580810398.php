<div class="profile-card <?php echo e($game->access_id ==3 && auth()->id() != $game->user_id ? 'hide': ''); ?>" >
    <img src="<?php echo e($game->cover); ?>" alt="" class="card-img">
    <div class="card-body">
        <div class="card-body-top">
            <div class="title-row" style="margin-bottom: 10px; justify-content: flex-start">
                <a href="<?php echo e(route('games.show', $game->id)); ?>" class="game-title" style="margin-bottom: 0"><?php echo e($game->name); ?></a>
                <div class="profile-likes">
                    <img src="<?php echo e(asset('/icons/like-black.svg')); ?>" alt="">
                    <span><?php echo e($game->count_likes); ?></span>
                </div>
            </div>
            <p class="game-tags"> Тэги:
                <?php $__empty_1 = true; $__currentLoopData = $game->gameTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('games.catalog', $tag->tag_id)); ?>" class="tags"><?php echo e($tag->tag->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span>Метки отсутствуют</span>
                <?php endif; ?>
            </p>
            <p class="game-check">Статус: <?php echo e($game->check->name); ?></p>


        </div>
        <?php if(auth()->id() == $game->user_id): ?>
            <div class="btns">
                <a href="<?php echo e(route('games.edit', $game->id)); ?>" class="btn nav-link" style="background: #B296DF">Редактировать</a>
                <form action="<?php echo e(route('games.delete', $game->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn nav-link" style="background: #ED8989">Удалить</button>
                </form>
                <?php if($game->access_id != 3): ?>
                    <a href="<?php echo e(route('games.hide', $game->id)); ?>" class="btn nav-link"  style="background: #96B4C4">Скрыть</a>
                <?php else: ?>
                    <a href="<?php echo e(route('games.open', $game->id)); ?>" class="btn nav-link"  style="background: #96B4C4">Показать</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p class="date-last-update">Последнее обновление: <?php echo e($game->dateClassic($game->updated_at)); ?></p>
        <?php endif; ?>
    </div>

</div>
<?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/inc/profile-card.blade.php ENDPATH**/ ?>