<?php $__env->startSection('title', $game->name); ?>
<?php $__env->startSection('content'); ?>
        <a href="<?php echo e(route('admin.games.check')); ?>">Назад</a>
        <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <p id="statusMessage" class="alert alert-success" hidden></p>
            <div class="main-game-info">
                <img class="main-game-img" src="<?php echo e($game->cover); ?>">
                <div class="main-game-chars">
                    <div class="title-row">
                        <div class="title-left">
                            <p class="main-game-title"><?php echo e($game->name); ?></p>
                        </div>
                        <div class="addition-inf">
                            <p><?php echo e($game->dateClassic($game->updated_at)); ?></p>
                        </div>
                    </div>

                    <a href="<?php echo e(route('user.profile', $game->user_id)); ?>" class="game-author">Автор: <?php echo e($game->user->username); ?></a>
                    <p class="main-game-tags"> Тэги:
                        <?php $__empty_1 = true; $__currentLoopData = $game->gameTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <a href="#" class="main-tags"><?php echo e($tag->tag->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span>Метки отсутствуют</span>
                        <?php endif; ?>
                    </p>

                    <p class="game-language">Язык: <?php echo e($game->language); ?></p>
                    <div class="game-desc">Описание: <?php echo e($game->description); ?></div>
                    <a class="game-link" href="<?php echo e($game->file_link); ?>" id="download" data-game="<?php echo e($game->id); ?>">Скачать новеллу</a>
                </div>
            </div>

            <div class="game-screens">
                <h3 class="show-h">Скриншоты</h3>
                <div class="screens-cont">
                    <?php if( count($game->images)>0): ?>
                        <div class="slider">
                            <?php $__currentLoopData = $game->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e($image->image); ?>" alt="screen" class="slider-img">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>

                <?php else: ?>
                    <p>Скриншоты пока отсутсвуют.</p>
                <?php endif; ?>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/admin/show.blade.php ENDPATH**/ ?>