<?php $__env->startSection('title', 'Регистрация'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="media-reg">

    <form action="<?php echo e(route('user.store')); ?>" method="post" class="reg">
        <?php echo csrf_field(); ?>
        <h1>Станьте частью сообщества!</h1>

        <input type="text" class="form-control" name="username" id="name"
               value="<?php echo e(old('username')); ?>" placeholder="Никнейм">
        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="is-invalid"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="date" class="form-control" name="birth_date" id="birth_date"
               value="<?php echo e(old('birth_date')); ?>" placeholder="Дата рождения">
        <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span  class="is-invalid"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


        <input type="email" class="form-control" name="email" id="email"
               value="<?php echo e(old('email')); ?>" placeholder="Email">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span  class="is-invalid"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="password" class="form-control " name="password"
               id="password" placeholder="Пароль">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span  class="is-invalid"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="password" class="form-control"
               name="password_confirmation" id="password_confirmation" placeholder="Повтор пароля">
        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span  class="is-invalid"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="rules" class="rules">
            <input type="checkbox" name="rules" id="rules">
            Я согласен с правилами сайта
        </label>
        <button id="btn-signup" class="btn register">Зарегистрироваться</button>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        document.getElementById('btn-signup').disabled = true

        document.getElementById('rules').addEventListener('change', (e) => {
            document.getElementById('btn-signup').disabled = !e.target.checked
        })
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('templates.custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/users/reg.blade.php ENDPATH**/ ?>