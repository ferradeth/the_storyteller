<?php $__env->startSection('title', 'Каталог'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="catalog">
        <?php echo $__env->make('inc.filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="games-catalog">
            <?php if(old('filter_games')): ?>
                <a href="<?php echo e(route('games.catalog')); ?>">Сбросить фильтр</a>
            <?php endif; ?>
            <?php if(isset($title)): ?>
                <?php echo e($title); ?>

            <?php endif; ?>
            <?php if($filter_tag): ?>
                <h2> Игры с меткой <?php echo e($filter_tag); ?></h2>
                    <a href="<?php echo e(route('games.catalog')); ?>">Посмотреть полный каталог</a>
            <?php endif; ?>
            <?php $__empty_1 = true; $__currentLoopData = old('filter_games')??$games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo $__env->make('inc.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="empty">Пока тут пусто :(</p>
            <?php endif; ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('js/fetch.js')); ?>"></script>
    <script>
        function likes(){
            const likeBtns = document.querySelectorAll('.likes')

            likeBtns.forEach(elem =>{
                elem.addEventListener('click', async (e)=>{
                    console.log(e.currentTarget.dataset.item)
                    if (elem.dataset.user){
                        let res = await postDataJSON('<?php echo e(route('games.like')); ?>', e.currentTarget.dataset.item, '<?php echo e(csrf_token()); ?>');
                        if(res){
                            elem.style.background = '#7645C7';
                            let last = document.querySelector(`div[data-item="${elem.dataset.item}"] span`).textContent;
                            console.log(last)
                            document.querySelector(`div[data-item="${elem.dataset.item}"] span`).textContent = (parseInt(last) + 1).toString()
                            elem.children[0].src = "<?php echo e(asset('/icons/like-active.svg')); ?>";
                        }
                        console.log(res)
                    }
                    else{
                        location = "<?php echo e(route('login')); ?>"
                    }
                })
            })
        }
        likes()
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('templates.custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/games/catalog.blade.php ENDPATH**/ ?>