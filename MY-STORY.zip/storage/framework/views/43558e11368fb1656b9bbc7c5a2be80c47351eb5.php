<footer>
    <div class="footer-menu">
        <div class="menu-docs">
            <a href="<?php echo e(route('info')); ?>">О нас</a>
            <a href="#">Пользовательское соглашение</a>
            <a href="#">Политика конфиденциальности</a>
        </div>
        <p class="copyright">2022 My Story © All rights reserved</p>
    </div>
    <div class="footer-inf">
        <p class="site-info">
            Все игры на сайте добавляются пользователями. На сервере сайта не хранятся архивы с играми, только ссылки на файлообменники.
            <br>
            <br>
            Если какая-то ссылка нарушает ваши авторские права, свяжитесь с файлообменником для блокировки архива. Также можете связаться с нами и мы удалим ссылку.
        </p>

    </div>
</footer>
<?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/inc/footer.blade.php ENDPATH**/ ?>