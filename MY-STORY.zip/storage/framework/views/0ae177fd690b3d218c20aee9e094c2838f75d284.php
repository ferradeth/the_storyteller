<?php $__env->startSection('title', 'Вход'); ?>
<?php $__env->startSection('content'); ?>

<main class="media-reg">
    <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(route('login.check')); ?>" method="post" class="reg">
        <?php echo csrf_field(); ?>
        <h1>Авторизация</h1>

        <input type="email" class="form-control" name="email" id="email"
               value="<?php echo e(old('email')); ?>" placeholder="Email">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span  class="is-invalid"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="password" class="form-control " name="password"
               id="password" placeholder="Пароль">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span  class="is-invalid"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button id="btn-signup" class="btn register" style="margin-left: 0">Войти</button>
        <p>Ещё нет аккаунта? Тогда <a href="<?php echo e(route('user.reg')); ?>">зарегистрируйтесь</a>!</p>
    </form>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\MY-STORY\resources\views/users/login.blade.php ENDPATH**/ ?>